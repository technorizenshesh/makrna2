package com.example.onlinemaklarna;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.databinding.DataBindingUtil;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.example.onlinemaklarna.databinding.ActivityHomeDashboardBinding;

import Activity.Activity_loadfrag;

public class HomeDashboardActivity extends AppCompatActivity {

    Context mContext;
    ActivityHomeDashboardBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this,R.layout.activity_home_dashboard);
        mContext = HomeDashboardActivity.this;

        init();

    }

    private void init() {

        binding.tvbuy.setBackgroundColor(ContextCompat.getColor(mContext,R.color.White));
        binding.tvbuy.setTextColor(ContextCompat.getColor(mContext,R.color.blue));

        binding.tvbuy.setOnClickListener(v -> {
            binding.tvbuy.setBackgroundColor(ContextCompat.getColor(mContext,R.color.White));
            binding.tvbuy.setTextColor(ContextCompat.getColor(mContext,R.color.blue));

            binding.tvrent.setBackgroundColor(ContextCompat.getColor(mContext,R.color.home_back_blue));
            binding.tvrent.setTextColor(ContextCompat.getColor(mContext,R.color.White));

            binding.tvsell.setBackgroundColor(ContextCompat.getColor(mContext,R.color.home_back_blue));
            binding.tvsell.setTextColor(ContextCompat.getColor(mContext,R.color.White));
        });

        binding.tvrent.setOnClickListener(v -> {
            binding.tvrent.setBackgroundColor(ContextCompat.getColor(mContext,R.color.White));
            binding.tvrent.setTextColor(ContextCompat.getColor(mContext,R.color.blue));

            binding.tvbuy.setBackgroundColor(ContextCompat.getColor(mContext,R.color.home_back_blue));
            binding.tvbuy.setTextColor(ContextCompat.getColor(mContext,R.color.White));

            binding.tvsell.setBackgroundColor(ContextCompat.getColor(mContext,R.color.home_back_blue));
            binding.tvsell.setTextColor(ContextCompat.getColor(mContext,R.color.White));

        });

        binding.tvsell.setOnClickListener(v -> {
            binding.tvsell.setBackgroundColor(ContextCompat.getColor(mContext,R.color.White));
            binding.tvsell.setTextColor(ContextCompat.getColor(mContext,R.color.blue));

            binding.tvrent.setBackgroundColor(ContextCompat.getColor(mContext,R.color.home_back_blue));
            binding.tvrent.setTextColor(ContextCompat.getColor(mContext,R.color.White));

            binding.tvbuy.setBackgroundColor(ContextCompat.getColor(mContext,R.color.home_back_blue));
            binding.tvbuy.setTextColor(ContextCompat.getColor(mContext,R.color.White));
        });

        binding.seeallVilla.setOnClickListener(v -> {
            startActivity(new Intent(mContext, Activity_loadfrag.class).putExtra("type","featured_villa"));
        });

        binding.seeMoreLatestProperties.setOnClickListener(v -> {
            startActivity(new Intent(mContext, Activity_loadfrag.class).putExtra("type","featured_Properties"));
        });

        binding.home1.setOnClickListener(v -> {
            mContext.startActivity(new Intent(mContext, Activity_loadfrag.class).putExtra("type","property_detail"));
        });

        binding.home2.setOnClickListener(v -> {
            mContext.startActivity(new Intent(mContext, Activity_loadfrag.class).putExtra("type","property_detail"));
        });

        binding.home3.setOnClickListener(v -> {
            mContext.startActivity(new Intent(mContext, Activity_loadfrag.class).putExtra("type","property_detail"));
        });


    }


}

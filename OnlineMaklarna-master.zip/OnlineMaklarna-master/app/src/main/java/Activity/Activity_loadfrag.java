package Activity;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.example.onlinemaklarna.R;

import Fragments.AddPropertyFragment;
import Fragments.Fragment_ItemDetails;
import Fragments.Fragment_filter;
import Fragments.PlotsVillaSeeMoreFragment;
import Fragments.PropertiesSeeMoreFragment;

public class Activity_loadfrag extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loadfrag);

        if (getIntent().getExtras()!=null) {

            String type=getIntent().getExtras().getString("type");

            if (type.equals("property_detail")){
               FragTrans(new Fragment_ItemDetails());
            } else if ((type.equals("searchfilter"))){
                FragTrans(new Fragment_filter());
            } else if(type.equals("Add_property")){
                FragTrans(new AddPropertyFragment());
            } else if(type.equals("featured_villa")){
                FragTrans(new PlotsVillaSeeMoreFragment());
            } else if(type.equals("featured_Properties")) {
                FragTrans(new PropertiesSeeMoreFragment());
            }

            /*if (type.equals("two")){
                FragTrans(new Fragment_restolist());
            }
            if (type.equals("three")){
                FragTrans(new Fragment_categories());
            }
            if (type.equals("four")){
                FragTrans(new Fragment_categories_Items());
            }
            if (type.equals("five")){
                FragTrans(new Fragment_YourCart());
            }
            if (type.equals("six")){
                FragTrans(new Fragment_address());
            }
            if (type.equals("seven")){
                FragTrans(new Fragment_filter());
            }*/

        }
    }
    public void FragTrans(Fragment fragment){

       // Fragment_restrodetails fragment2 = new Fragment_restrodetails();
        FragmentManager fragmentManager =   getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.lodfram_container, fragment);
        fragmentTransaction.commit();
    }
}

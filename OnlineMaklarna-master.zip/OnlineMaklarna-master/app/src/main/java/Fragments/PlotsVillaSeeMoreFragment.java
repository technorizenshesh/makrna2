package Fragments;


import android.content.Context;
import android.os.Bundle;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.onlinemaklarna.R;
import com.example.onlinemaklarna.databinding.FragmentPlotsVillaSeeMoreBinding;

/**
 * A simple {@link Fragment} subclass.
 */
public class PlotsVillaSeeMoreFragment extends Fragment {


    Context mContext;
    FragmentPlotsVillaSeeMoreBinding binding;

    public PlotsVillaSeeMoreFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        mContext = getActivity();
        binding = DataBindingUtil.inflate(inflater,R.layout.fragment_plots_villa_see_more, container, false);

        init();

        // Inflate the layout for this fragment
        return binding.getRoot();
    }

    private void init() {
        binding.ivBack.setOnClickListener(v -> {
            getActivity().finish();
        });
    }


}
